# Sticker Audio Bot

Proyecto inicial de WhatsApp Cloud API. Recibe imágenes y las convierte en stickers WebP; si recibe un audio, lo devuelve como mensaje de audio separado.

## Importante
- Un sticker normal de WhatsApp no puede llevar audio incorporado. El bot envía el sticker y el audio como mensajes separados.
- Necesitas una cuenta de Meta for Developers, una app de WhatsApp Cloud API, un token de acceso y un `PHONE_NUMBER_ID`.
- Necesitas publicar este proyecto en un servicio que permita una URL HTTPS pública para el webhook.
- No compartas tu token de Meta. Nunca lo publiques en GitHub ni lo envíes por chat.

## Variables
Copia `.env.example` como `.env` y completa:
- `VERIFY_TOKEN`: frase secreta que inventas tú.
- `WHATSAPP_TOKEN`: token de acceso de Meta.
- `PHONE_NUMBER_ID`: identificador del número de WhatsApp de Meta.
- `GRAPH_API_VERSION`: versión de Graph API habilitada en tu app.

## Ejecutar
Requiere Node.js 20 o superior.

```bash
npm install
npm start
```

Configura en Meta el webhook:
- Callback URL: `https://TU-DOMINIO/webhook`
- Verify token: el mismo valor de `VERIFY_TOKEN`
- Suscribe el campo `messages`.

## Prueba
Envía `/menu` al número de prueba de WhatsApp. Después envía una imagen o un audio.

## Límites de esta versión
- Los comandos `/animado` y `/recortar` son respuestas informativas; todavía no procesan esos formatos.
- El bot no guarda archivos de forma permanente.
- Para producción, añade validación de firma del webhook, límites de tamaño, control de errores, privacidad y limpieza de archivos.
