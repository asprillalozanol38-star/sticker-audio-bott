require("dotenv").config();
const express = require("express");
const sharp = require("sharp");

const app = express();
app.use(express.json({ limit: "2mb" }));

const {
  PORT = 3000,
  VERIFY_TOKEN,
  WHATSAPP_TOKEN,
  PHONE_NUMBER_ID,
  GRAPH_API_VERSION = "v22.0"
} = process.env;

const graph = `https://graph.facebook.com/${GRAPH_API_VERSION}`;
const authHeaders = { Authorization: `Bearer ${WHATSAPP_TOKEN}` };

app.get("/", (_req, res) => res.send("Sticker Audio Bot está activo."));
app.get("/webhook", (req, res) => {
  const mode = req.query["hub.mode"];
  const token = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];
  if (mode === "subscribe" && token === VERIFY_TOKEN) return res.status(200).send(challenge);
  return res.sendStatus(403);
});

async function sendText(to, body) {
  return fetch(`${graph}/${PHONE_NUMBER_ID}/messages`, {
    method: "POST",
    headers: { ...authHeaders, "Content-Type": "application/json" },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to,
      type: "text",
      text: { body }
    })
  });
}

async function getMedia(mediaId) {
  const metaRes = await fetch(`${graph}/${mediaId}`, { headers: authHeaders });
  if (!metaRes.ok) throw new Error("No se pudo consultar el archivo multimedia.");
  const meta = await metaRes.json();
  const fileRes = await fetch(meta.url, { headers: authHeaders });
  if (!fileRes.ok) throw new Error("No se pudo descargar el archivo multimedia.");
  return Buffer.from(await fileRes.arrayBuffer());
}

async function uploadMedia(buffer, mimeType) {
  const form = new FormData();
  form.append("messaging_product", "whatsapp");
  form.append("type", mimeType);
  form.append("file", new Blob([buffer], { type: mimeType }), "sticker.webp");
  const response = await fetch(`${graph}/${PHONE_NUMBER_ID}/media`, {
    method: "POST",
    headers: authHeaders,
    body: form
  });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error?.message || "Error subiendo el archivo.");
  return result.id;
}

async function sendSticker(to, mediaId) {
  return fetch(`${graph}/${PHONE_NUMBER_ID}/messages`, {
    method: "POST",
    headers: { ...authHeaders, "Content-Type": "application/json" },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to,
      type: "sticker",
      sticker: { id: mediaId }
    })
  });
}

async function sendAudio(to, buffer, mimeType) {
  const mediaId = await uploadMedia(buffer, mimeType);
  return fetch(`${graph}/${PHONE_NUMBER_ID}/messages`, {
    method: "POST",
    headers: { ...authHeaders, "Content-Type": "application/json" },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to,
      type: "audio",
      audio: { id: mediaId }
    })
  });
}

async function handleMessage(message) {
  const from = message.from;
  if (message.type === "text") {
    const command = message.text.body.trim().toLowerCase();
    if (["/menu", "menu", "hola", "ayuda"].includes(command)) {
      await sendText(from,
        "🤖 STICKER AUDIO BOT\\n\\n" +
        "📸 Envíame una imagen y la convertiré en sticker.\\n" +
        "🎵 Envíame un audio y te lo devolveré.\\n\\n" +
        "Comandos:\\n/menu — ver ayuda\\n/sticker — envía una imagen después\\n/audio — envía un audio después\\n\\n" +
        "Nota: el audio se envía como mensaje separado; WhatsApp no permite sonido dentro de un sticker normal."
      );
    } else if (command === "/sticker") {
      await sendText(from, "📸 Ahora envíame una imagen como foto o documento.");
    } else if (command === "/audio") {
      await sendText(from, "🎵 Ahora envíame un audio y te lo devolveré.");
    } else if (command === "/animado") {
      await sendText(from, "🎬 La función de stickers animados se añadirá en una próxima versión.");
    } else if (command === "/recortar") {
      await sendText(from, "✂️ La eliminación automática de fondos se añadirá en una próxima versión.");
    } else {
      await sendText(from, "No reconozco ese comando. Escribe /menu para ver las opciones.");
    }
    return;
  }

  if (message.type === "image") {
    const original = await getMedia(message.image.id);
    const webp = await sharp(original)
      .rotate()
      .resize(512, 512, { fit: "contain", background: { r: 0, g: 0, b: 0, alpha: 0 } })
      .webp({ quality: 82 })
      .toBuffer();
    const mediaId = await uploadMedia(webp, "image/webp");
    const result = await sendSticker(from, mediaId);
    if (!result.ok) throw new Error("WhatsApp no pudo enviar el sticker.");
    return;
  }

  if (message.type === "audio") {
    const audio = await getMedia(message.audio.id);
    const mime = message.audio.mime_type || "audio/ogg";
    await sendAudio(from, audio, mime);
    return;
  }

  await sendText(from, "Por ahora puedo procesar imágenes y audios. Escribe /menu para ver cómo usarme.");
}

app.post("/webhook", async (req, res) => {
  // Responder rápido a Meta; procesar después.
  res.sendStatus(200);
  try {
    const entries = req.body.entry || [];
    for (const entry of entries) {
      for (const change of entry.changes || []) {
        for (const message of change.value?.messages || []) {
          await handleMessage(message);
        }
      }
    }
  } catch (error) {
    console.error("Error procesando mensaje:", error.message);
  }
});

app.listen(PORT, () => console.log(`Bot escuchando en puerto ${PORT}`));
